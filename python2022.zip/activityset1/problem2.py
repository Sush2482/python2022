
hrs=input("Enter Hour:")
rate=input("Enter Rate per Hour:")
pay=float(hrs)*float(rate)

print("Pay:", pay)

